/*
Author: Ayomiposi Fadeni
Date: 4th of April, 2025
Description: This program analyzes data from red light cameras. The program analyzes red light
camera violation data from a selected file and provides a menu to a user to which the user can obtain 
informational insights and summaries.
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <unordered_set>
#include <unordered_map>
#include <string>

using namespace std;

// Class to store information for a camera record
class CameraRecord {
private:
    string intersection;
    string address;
    int cameraNumber;
    string date;
    int violations;
    string neighborhood;

public:
    // Constructor
    CameraRecord(string inter, string addr, int camNum, string dT, int viol, string neigh)
        : intersection(inter), address(addr), cameraNumber(camNum), date(dT), violations(viol), neighborhood(neigh) {}

    // Getter methods
    string getIntersection() const { return intersection; }
    string getAddress() const { return address; }
    int getCameraNumber() const { return cameraNumber; }
    string getDate() const { return date; }
    int getViolations() const { return violations; }
    string getNeighborhood() const { return neighborhood; }
};

// Function to read data from a file
vector<CameraRecord> readDataFromFile(const string &filename) {
    vector<CameraRecord> records;
    ifstream file(filename);
    
    if (!file.is_open()) {
        cout << "Error opening file!" << endl;
        return records;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string intersection, address, date, neighborhood, cameraNumStr, violationsStr;
        int cameraNumber, violations;

        getline(ss, intersection, ',');
        getline(ss, address, ',');
        getline(ss, cameraNumStr, ',');
        getline(ss, date, ',');
        getline(ss, violationsStr, ',');
        getline(ss, neighborhood, ',');
        
        try {
            cameraNumber = stoi(cameraNumStr);
            violations = stoi(violationsStr);
            
            records.emplace_back(intersection, address, cameraNumber, date, violations, neighborhood);
        } catch (const exception& e) {
            cerr << "Error parsing line: " << line << endl;
        }
    }
    
    file.close();
    return records;
}

// Function prototypes
void displayMenu();
void dataOverview(const vector<CameraRecord>& records);
void resultsByNeighborhood(const vector<CameraRecord>& records);
void chartByMonth(const vector<CameraRecord>& records);
void searchCameras(const vector<CameraRecord>& records);

// Main function
int main() {
    string filename;
    cout << "Enter file to use: ";
    cin >> filename;

    vector<CameraRecord> records = readDataFromFile(filename);
    if (records.empty()) {
        cout << "No records found. Exiting." << endl;
        return 1;
    }

    int choice;
    do {
        displayMenu();
        cin >> choice;
        cin.ignore();

        switch (choice) {
            case 1:
                dataOverview(records);
                break;
            case 2:
                resultsByNeighborhood(records);
                break;
            case 3:
                chartByMonth(records);
                break;
            case 4:
                searchCameras(records);
                break;
            case 5:
                break;
            default:
                cout << "Invalid choice, try again." << endl;
        }
    } while (choice != 5);

    return 0;
}

// Function to display menu
void displayMenu() {
    cout << "\nSelect a menu option: " << endl; 
    cout << "  1. Data overview" << endl;
    cout << "  2. Results by neighborhood" << endl;
    cout << "  3. Chart by month" << endl;
    cout << "  4. Search for cameras" << endl;
    cout << "  5. Exit" << endl;
    cout << "Your choice: ";
}

// Function to give dataoverview of a camera record
void dataOverview(const vector<CameraRecord>& records) {
    vector<int> uniqueCameras;
    int totalViolations = 0;
    int maxViolations = 0;
    string maxViolationIntersection;
    string maxViolationDate;

    for (int i = 0; i < records.size(); i++){
        const CameraRecord& record = records[i];
        totalViolations += record.getViolations();
        
        if (find(uniqueCameras.begin(), uniqueCameras.end(), record.getCameraNumber()) == uniqueCameras.end()){
            uniqueCameras.push_back(record.getCameraNumber());
        }
        if (record.getViolations() > maxViolations){
            maxViolations = record.getViolations();
            maxViolationIntersection = record.getIntersection();
            maxViolationDate = record.getDate();
        }
    }
    string month, day, year;
    stringstream dateStream(maxViolationDate);
    getline(dateStream, year, '-');
    getline(dateStream, month, '-');
    getline(dateStream, day, '-');

    string correctDate = month + '-' + day + '-' + year;
    
    cout << "Read file with " << records.size() << " records." << endl;
    cout << "There are " << uniqueCameras.size() << " cameras." << endl;
    cout << "A total of " << totalViolations << " violations." << endl;
    cout << "The most violations in one day were " << maxViolations << " on " 
         << correctDate << " at " << maxViolationIntersection << endl;
}


// Function to give the number of cameras and violations for each neighborhood
void resultsByNeighborhood(const vector<CameraRecord>& records) {
    struct NeighborhoodData {
        string name;
        int cameras = 0;
        int violations = 0;
        vector<int> cameraIds; // To track unique cameras
    };

    vector<NeighborhoodData> neighborhoods;
    
    for (const auto& record : records) {
        bool found = false;
        for (auto& neighborhood : neighborhoods) {
            if (neighborhood.name == record.getNeighborhood()) {
                neighborhood.violations += record.getViolations();
                
                int cameraId = record.getCameraNumber();
                if (find(neighborhood.cameraIds.begin(), neighborhood.cameraIds.end(), cameraId) 
                      == neighborhood.cameraIds.end()) {
                    neighborhood.cameraIds.push_back(cameraId);
                    neighborhood.cameras++; 
                }
                
                found = true;
                break;
            }
        }
        
        if (!found) {
            NeighborhoodData newNeighborhood;
            newNeighborhood.name = record.getNeighborhood();
            newNeighborhood.violations = record.getViolations();
            newNeighborhood.cameraIds.push_back(record.getCameraNumber());
            newNeighborhood.cameras = 1;
            neighborhoods.push_back(newNeighborhood);
        }
    }

    // Sort neighborhoods by violations in descending order
    sort(neighborhoods.begin(), neighborhoods.end(), [](const NeighborhoodData& a, const NeighborhoodData& b) {
        return a.violations > b.violations;
    });

    cout << "\n";
    for (const auto& neighborhood : neighborhoods) {
        cout << left << setw(25) << neighborhood.name 
             << right << setw(4) << neighborhood.cameras 
             << right << setw(7) << neighborhood.violations << endl;
    }
}

// Function to give the number of violations for each month
void chartByMonth(const vector<CameraRecord>& records) {
    int monthViolations[12] = {0};
    for (const auto& record : records) {
        int month = stoi(record.getDate().substr(5, 2)) - 1;
        monthViolations[month] += record.getViolations();
    }

    string months[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    cout << endl;
    for (int i = 0; i < 12; i++) {
        cout << left << setw(12) << months[i] << string(monthViolations[i] / 1000, '*') << endl;
    }
}

// Function to search for a desired camera
void searchCameras(const vector<CameraRecord>& records) {
    string query;
    cout << "What should we search for? ";
    getline(cin, query);
    transform(query.begin(), query.end(), query.begin(), ::tolower);

    bool found = false;
    unordered_set<int> displayedCameras;

    for(const auto& record : records) {
        string interLower = record.getIntersection();
        string neighLower = record.getNeighborhood();
        transform(interLower.begin(), interLower.end(), interLower.begin(), ::tolower);
        transform(neighLower.begin(), neighLower.end(), neighLower.begin(), ::tolower);

        if ((interLower.find(query) != string::npos || neighLower.find(query) != string::npos) &&
            displayedCameras.find(record.getCameraNumber()) == displayedCameras.end()) {
                displayedCameras.insert(record.getCameraNumber());
                cout << "Camera: " << record.getCameraNumber() << endl;
                cout << "Address: " << record.getAddress() << endl;
                cout << "Intersection: " << record.getIntersection() << endl; 
                cout << "Neighborhood: " << record.getNeighborhood() << endl;
                cout << endl; 
                found = true;
        }
    }

    if (!found) {
        cout << "No cameras found." << endl;
    }
}